// Menu declaration of buttons
const chocolat = document.getElementById('chocolat');
const cream = document.getElementById('cream');
const cho2 = document.getElementById('cho2');
// Menu declaration of items
const appear = document.getElementById('chocolatsection');
const creamsection = document.getElementById('creamsection');
const co2chocolat = document.getElementById('co2chocolat');

// chocalat button
chocolat.addEventListener('click', function() {
    appear.classList.remove('d-none');
    creamsection.classList.add('d-none');
    co2chocolat.classList.add('d-none');
})

// cream button
cream.addEventListener('click', function() {
    appear.classList.add('d-none');
    creamsection.classList.remove('d-none');
    co2chocolat.classList.add('d-none');
});
cho2.addEventListener('click', function() {
        appear.classList.add('d-none');
        creamsection.classList.add('d-none');
        co2chocolat.classList.remove('d-none');

    })
    // back to top    $(window).scroll(function() {
if ($(window).scrollTop() > 100) {
    $('#header').addClass('header-scrolled');
}

// Back to top button
$(document).ready(function() {
    // <!--Smooth Page Scroll to Top-->
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();
        } else {
            $('.scrollup').fadeOut();
        }
    });

    $('.scrollup').click(function() {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });
    // <!--//-->

});